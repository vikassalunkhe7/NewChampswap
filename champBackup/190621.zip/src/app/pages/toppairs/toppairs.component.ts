import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toppairs',
  templateUrl: './toppairs.component.html',
  styleUrls: ['./toppairs.component.scss']
})
export class ToppairsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
